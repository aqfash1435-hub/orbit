module.exports = {
  root: true,
  extends: 'universe/node',
  ignorePatterns: ['build/**', 'node_modules/**'],
};
