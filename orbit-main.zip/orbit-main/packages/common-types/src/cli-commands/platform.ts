export enum Platform {
  Android = 'android',
  Ios = 'ios',
  All = 'all',
}
