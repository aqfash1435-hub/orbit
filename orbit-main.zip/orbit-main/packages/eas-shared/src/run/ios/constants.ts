export const EXPO_GO_BUNDLE_IDENTIFIER = 'host.exp.Exponent';
export const APP_STORE_BUNDLE_IDENTIFIER = 'com.apple.AppStore';

export const EXPO_GO_APP_STORE_URL = 'https://apps.apple.com/br/app/expo-go/id982107779';
