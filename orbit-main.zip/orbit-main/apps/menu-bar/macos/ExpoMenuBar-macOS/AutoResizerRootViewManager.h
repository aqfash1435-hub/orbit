#import <React/RCTViewManager.h>

@interface AutoResizerRootViewManager : RCTViewManager

@end
