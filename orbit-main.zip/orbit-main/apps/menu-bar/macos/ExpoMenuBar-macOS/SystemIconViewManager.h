#import <React/RCTViewManager.h>

@interface SystemIconViewManager : RCTViewManager

@end
