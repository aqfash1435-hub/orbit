#import <React/RCTView.h>

@interface AutoResizerRootView : RCTView

@property(nonatomic, assign) BOOL enabled;
@property (nonatomic, assign) CGFloat maxRelativeHeight;

@end
