#import <React/RCTViewManager.h>

@interface CheckboxManager : RCTViewManager

@end
