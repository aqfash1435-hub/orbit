#import <React/RCTImageView.h>

@interface RCTImageView (Private)
 
- (void)updateWithImage:(UIImage *)image;

@end
