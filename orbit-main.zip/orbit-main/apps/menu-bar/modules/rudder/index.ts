import RudderClient from './src/RudderModule';

export { RudderClient };
