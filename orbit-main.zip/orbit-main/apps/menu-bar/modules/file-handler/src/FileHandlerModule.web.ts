import { requireElectronModule } from 'react-native-electron-modules/build/requireElectronModule';

const FileHandler = requireElectronModule('FileHandler');

export default FileHandler;
