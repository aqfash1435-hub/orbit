export { Switch } from 'react-native';
