export { Linking } from 'react-native';
