import MenuBarModule from '../../modules/menu-bar';
export default MenuBarModule;
