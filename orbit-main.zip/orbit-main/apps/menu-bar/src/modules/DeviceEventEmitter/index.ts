export { DeviceEventEmitter } from 'react-native';
