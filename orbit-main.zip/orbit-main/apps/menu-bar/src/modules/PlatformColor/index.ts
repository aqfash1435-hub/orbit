export { PlatformColor } from 'react-native';
